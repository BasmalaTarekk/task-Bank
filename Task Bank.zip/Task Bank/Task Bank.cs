﻿using System;
using System.Collections.Generic;
using System.Linq;

public class Bank
{
    public string Name { get; private set; }
    public string BranchCode { get; private set; }
    private List<Customer> customers = new();

    public Bank(string name, string branchCode)
    {
        Name = name;
        BranchCode = branchCode;
    }
    public void AddCustomer(Customer customer)
    {
        customers.Add(customer);
    }
    public bool RemoveCustomer(int customerId)
    {
        var customer = customers.FirstOrDefault(c => c.Id == customerId);
        if (customer != null && customer.Accounts.All(a => a.Balance == 0))
        {
            customers.Remove(customer);
            return true;
        }
        return false;
    }
    public List<Customer> SearchCustomers(string query)
    {
        query = query.ToLower();
        return customers.Where(c =>
            c.FullName.ToLower().Contains(query) ||
            c.NationalID.ToLower().Contains(query)
        ).ToList();
    }
    public void ShowReport()
    {
        Console.WriteLine($"Bank: {Name} - Branch: {BranchCode}");
        foreach(var customer in customers)
        {
            Console.WriteLine($"Customer ID: {customer.Id}, Name: {customer.FullName}, National ID: {customer.NationalID}");
            foreach(var acc in customer.Accounts)
            {
                Console.WriteLine($"\tAccount #{acc.AccountNumber} - Type: {acc.GetType().Name}, Balance: {acc.Balance:C}, Opened: {acc.DateOpened.ToShortDateString()}");
            }
            Console.WriteLine($"Total Balance: {customer.GetTotalBalance():C}");
            Console.WriteLine(new string('-', 50));
        }
    }
}
public class Customer
{
    private static int idCounter = 1;

    public int Id { get; private set; }
    public string FullName { get; private set; }
    public string NationalID { get; private set; }
    public DateTime DateOfBirth { get; private set; }
    public List<Account> Accounts { get; private set; } = new();

    public Customer(string fullName, string nationalId, DateTime dob)
    {
        Id = idCounter++;
        FullName = fullName;
        NationalID = nationalId;
        DateOfBirth = dob;
    }

    public void UpdateDetails(string fullName, DateTime dob)
    {
        FullName = fullName;
        DateOfBirth = dob;
    }

    public void AddAccount(Account account)
    {
        Accounts.Add(account);
    }

    public decimal GetTotalBalance()
    {
        return Accounts.Sum(a => a.Balance);
    }

}
public abstract class Account
{
    private static int accountCounter = 1000;

    public int AccountNumber { get; private set; }
    public decimal Balance { get; protected set; }
    public DateTime DateOpened { get; private set; }

    protected List<string> transactionHistory = new();

    public Account()
    {
        AccountNumber = accountCounter++;
        DateOpened = DateTime.Now;
    }

    public virtual void Deposit(decimal amount)
    {
        if (amount <= 0) throw new ArgumentException("Amount must be positive");
        Balance += amount;
        transactionHistory.Add($"{DateTime.Now}: Deposit {amount:C}, New Balance: {Balance:C}");
    }

    public virtual bool Withdraw(decimal amount)
    {
        if (amount <= 0) throw new ArgumentException("Amount must be positive");
        if (Balance >= amount)
        {
            Balance -= amount;
            transactionHistory.Add($"{DateTime.Now}: Withdraw {amount:C}, New Balance: {Balance:C}");
            return true;
        }
        return false;
    }

    public void Transfer(Account toAccount, decimal amount)
    {
        if (Withdraw(amount))
        {
            toAccount.Deposit(amount);
            transactionHistory.Add($"{DateTime.Now}: Transfer {amount:C} to Account #{toAccount.AccountNumber}");
            toAccount.transactionHistory.Add($"{DateTime.Now}: Received {amount:C} from Account #{AccountNumber}");
        }
        else
        {
            throw new InvalidOperationException("Insufficient funds for transfer");
        }
    }

    public void ShowTransactionHistory()
    {
        Console.WriteLine($"Transaction History for Account #{AccountNumber}:");
        foreach(var t in transactionHistory)
        {
            Console.WriteLine(t);
        }
    }
}
public class SavingsAccount : Account
{
    public decimal InterestRate { get; private set; }  // e.g., 0.05 for 5%

    public SavingsAccount(decimal interestRate)
    {
        InterestRate = interestRate;
    }

    public decimal CalculateMonthlyInterest()
    {
        return Balance * InterestRate / 12;
    }

    public void AddMonthlyInterest()
    {
        decimal interest = CalculateMonthlyInterest();
        Deposit(interest);
        transactionHistory.Add($"{DateTime.Now}: Monthly interest added {interest:C}");
    }
}
public class CurrentAccount : Account
{
    public decimal OverdraftLimit { get; private set; }

    public CurrentAccount(decimal overdraftLimit)
    {
        OverdraftLimit = overdraftLimit;
    }

    public override bool Withdraw(decimal amount)
    {
        if (amount <= 0) throw new ArgumentException("Amount must be positive");
        if (Balance + OverdraftLimit >= amount)
        {
            Balance -= amount;
            transactionHistory.Add($"{DateTime.Now}: Withdraw {amount:C}, New Balance: {Balance:C}");
            return true;
        }
        return false;
    }

    class Program
    {
        static void Main()
        {
            var bank = new Bank("My Bank", "001");

            var customer1 = new Customer("Ali Ahmed", "123456789", new DateTime(1990, 5, 1));
            var customer2 = new Customer("Sara Mohamed", "987654321", new DateTime(1985, 8, 15));

            bank.AddCustomer(customer1);
            bank.AddCustomer(customer2);

            var savings1 = new SavingsAccount(0.05m);
            var current1 = new CurrentAccount(1000);

            customer1.AddAccount(savings1);
            customer1.AddAccount(current1);

            savings1.Deposit(5000);
            current1.Deposit(2000);

            var savings2 = new SavingsAccount(0.03m);
            customer2.AddAccount(savings2);
            savings2.Deposit(3000);

            savings1.Withdraw(1000);
            current1.Withdraw(2500);

            savings1.Transfer(savings2, 500);

            savings1.AddMonthlyInterest();
            savings2.AddMonthlyInterest();


            bank.ShowReport();

            savings1.ShowTransactionHistory();
            bool removed = bank.RemoveCustomer(customer1.Id);
            Console.WriteLine($"Remove customer1 success? {removed}");

            savings1.Withdraw(savings1.Balance);
            current1.Withdraw(current1.Balance);

            removed = bank.RemoveCustomer(customer1.Id);
            Console.WriteLine($"Remove customer1 success? {removed}");
        }
    }
}
